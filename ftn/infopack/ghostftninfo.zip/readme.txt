# GHOSTnet infopack

Files for joining and setting up GHOSTnet FTN on your BBS.